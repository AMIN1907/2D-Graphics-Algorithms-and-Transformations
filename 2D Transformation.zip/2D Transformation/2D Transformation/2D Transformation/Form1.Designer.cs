﻿
namespace _2D_Transformation
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            pictureBox1 = new System.Windows.Forms.PictureBox();
            Rot = new System.Windows.Forms.CheckBox();
            Trans = new System.Windows.Forms.CheckBox();
            Scale = new System.Windows.Forms.CheckBox();
            Shear = new System.Windows.Forms.CheckBox();
            DegTrackBar = new System.Windows.Forms.TrackBar();
            RotXtrackBar = new System.Windows.Forms.TrackBar();
            RotYtrackBar = new System.Windows.Forms.TrackBar();
            TransXtrackBar = new System.Windows.Forms.TrackBar();
            TransYtrackBar = new System.Windows.Forms.TrackBar();
            ScaleXtrackBar = new System.Windows.Forms.TrackBar();
            ScaleYtrackBar = new System.Windows.Forms.TrackBar();
            ShearXtrackBar = new System.Windows.Forms.TrackBar();
            ShearYtrackBar = new System.Windows.Forms.TrackBar();
            CheckedFunc = new System.Windows.Forms.ListBox();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            label9 = new System.Windows.Forms.Label();
            DegLbl = new System.Windows.Forms.Label();
            RotX = new System.Windows.Forms.Label();
            RotY = new System.Windows.Forms.Label();
            TransX = new System.Windows.Forms.Label();
            TransY = new System.Windows.Forms.Label();
            ScaleX = new System.Windows.Forms.Label();
            ScaleY = new System.Windows.Forms.Label();
            ShearX = new System.Windows.Forms.Label();
            ShearY = new System.Windows.Forms.Label();
            Reset = new System.Windows.Forms.Button();
            cbFlipY = new System.Windows.Forms.CheckBox();
            pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)DegTrackBar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)RotXtrackBar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)RotYtrackBar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)TransXtrackBar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)TransYtrackBar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ScaleXtrackBar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ScaleYtrackBar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ShearXtrackBar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ShearYtrackBar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pictureBox1.Location = new System.Drawing.Point(12, 17);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new System.Drawing.Size(632, 397);
            pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // Rot
            // 
            Rot.AutoSize = true;
            Rot.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            Rot.Location = new System.Drawing.Point(765, 12);
            Rot.Name = "Rot";
            Rot.Size = new System.Drawing.Size(91, 21);
            Rot.TabIndex = 1;
            Rot.Text = "Rotation";
            Rot.UseVisualStyleBackColor = true;
            Rot.CheckedChanged += Rot_CheckedChanged;
            // 
            // Trans
            // 
            Trans.AutoSize = true;
            Trans.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            Trans.Location = new System.Drawing.Point(753, 191);
            Trans.Name = "Trans";
            Trans.Size = new System.Drawing.Size(115, 21);
            Trans.TabIndex = 2;
            Trans.Text = "Translation";
            Trans.UseVisualStyleBackColor = true;
            Trans.CheckedChanged += Trans_CheckedChanged;
            // 
            // Scale
            // 
            Scale.AutoSize = true;
            Scale.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            Scale.Location = new System.Drawing.Point(753, 325);
            Scale.Name = "Scale";
            Scale.Size = new System.Drawing.Size(67, 21);
            Scale.TabIndex = 3;
            Scale.Text = "Scale";
            Scale.UseVisualStyleBackColor = true;
            Scale.CheckedChanged += Scale_CheckedChanged;
            // 
            // Shear
            // 
            Shear.AutoSize = true;
            Shear.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            Shear.Location = new System.Drawing.Point(1080, 191);
            Shear.Name = "Shear";
            Shear.Size = new System.Drawing.Size(91, 21);
            Shear.TabIndex = 6;
            Shear.Text = "Shearing";
            Shear.UseVisualStyleBackColor = true;
            Shear.CheckedChanged += Shear_CheckedChanged;
            // 
            // DegTrackBar
            // 
            DegTrackBar.AutoSize = false;
            DegTrackBar.LargeChange = 1;
            DegTrackBar.Location = new System.Drawing.Point(753, 42);
            DegTrackBar.Maximum = 90;
            DegTrackBar.Minimum = -90;
            DegTrackBar.Name = "DegTrackBar";
            DegTrackBar.Size = new System.Drawing.Size(218, 38);
            DegTrackBar.TabIndex = 7;
            DegTrackBar.Scroll += DegTrackBar_Scroll;
            // 
            // RotXtrackBar
            // 
            RotXtrackBar.AutoSize = false;
            RotXtrackBar.LargeChange = 1;
            RotXtrackBar.Location = new System.Drawing.Point(753, 86);
            RotXtrackBar.Maximum = 50;
            RotXtrackBar.Minimum = -50;
            RotXtrackBar.Name = "RotXtrackBar";
            RotXtrackBar.Size = new System.Drawing.Size(218, 38);
            RotXtrackBar.TabIndex = 8;
            RotXtrackBar.Scroll += RotXtrackBar_Scroll;
            // 
            // RotYtrackBar
            // 
            RotYtrackBar.AutoSize = false;
            RotYtrackBar.LargeChange = 1;
            RotYtrackBar.Location = new System.Drawing.Point(753, 129);
            RotYtrackBar.Maximum = 50;
            RotYtrackBar.Minimum = -50;
            RotYtrackBar.Name = "RotYtrackBar";
            RotYtrackBar.Size = new System.Drawing.Size(218, 38);
            RotYtrackBar.TabIndex = 9;
            RotYtrackBar.Scroll += RotYtrackBar_Scroll;
            // 
            // TransXtrackBar
            // 
            TransXtrackBar.AutoSize = false;
            TransXtrackBar.LargeChange = 1;
            TransXtrackBar.Location = new System.Drawing.Point(753, 221);
            TransXtrackBar.Maximum = 150;
            TransXtrackBar.Minimum = -150;
            TransXtrackBar.Name = "TransXtrackBar";
            TransXtrackBar.Size = new System.Drawing.Size(218, 38);
            TransXtrackBar.TabIndex = 10;
            TransXtrackBar.Scroll += TransXtrackBar_Scroll;
            // 
            // TransYtrackBar
            // 
            TransYtrackBar.AutoSize = false;
            TransYtrackBar.LargeChange = 1;
            TransYtrackBar.Location = new System.Drawing.Point(753, 263);
            TransYtrackBar.Maximum = 150;
            TransYtrackBar.Minimum = -150;
            TransYtrackBar.Name = "TransYtrackBar";
            TransYtrackBar.Size = new System.Drawing.Size(218, 38);
            TransYtrackBar.TabIndex = 11;
            TransYtrackBar.Scroll += TransYtrackBar_Scroll;
            // 
            // ScaleXtrackBar
            // 
            ScaleXtrackBar.AutoSize = false;
            ScaleXtrackBar.LargeChange = 1;
            ScaleXtrackBar.Location = new System.Drawing.Point(733, 352);
            ScaleXtrackBar.Maximum = 20;
            ScaleXtrackBar.Minimum = 1;
            ScaleXtrackBar.Name = "ScaleXtrackBar";
            ScaleXtrackBar.Size = new System.Drawing.Size(218, 38);
            ScaleXtrackBar.TabIndex = 12;
            ScaleXtrackBar.Value = 10;
            ScaleXtrackBar.Scroll += ScaleXtrackBar_Scroll;
            // 
            // ScaleYtrackBar
            // 
            ScaleYtrackBar.AutoSize = false;
            ScaleYtrackBar.LargeChange = 1;
            ScaleYtrackBar.Location = new System.Drawing.Point(733, 393);
            ScaleYtrackBar.Maximum = 20;
            ScaleYtrackBar.Minimum = 1;
            ScaleYtrackBar.Name = "ScaleYtrackBar";
            ScaleYtrackBar.Size = new System.Drawing.Size(218, 38);
            ScaleYtrackBar.TabIndex = 13;
            ScaleYtrackBar.Value = 10;
            ScaleYtrackBar.Scroll += ScaleYtrackBar_Scroll;
            // 
            // ShearXtrackBar
            // 
            ShearXtrackBar.AutoSize = false;
            ShearXtrackBar.LargeChange = 1;
            ShearXtrackBar.Location = new System.Drawing.Point(1080, 221);
            ShearXtrackBar.Minimum = -10;
            ShearXtrackBar.Name = "ShearXtrackBar";
            ShearXtrackBar.Size = new System.Drawing.Size(218, 38);
            ShearXtrackBar.TabIndex = 14;
            ShearXtrackBar.Scroll += ShearXtrackBar_Scroll;
            // 
            // ShearYtrackBar
            // 
            ShearYtrackBar.AutoSize = false;
            ShearYtrackBar.LargeChange = 1;
            ShearYtrackBar.Location = new System.Drawing.Point(1080, 263);
            ShearYtrackBar.Minimum = -10;
            ShearYtrackBar.Name = "ShearYtrackBar";
            ShearYtrackBar.Size = new System.Drawing.Size(218, 38);
            ShearYtrackBar.TabIndex = 15;
            ShearYtrackBar.Scroll += ShearYtrackBar_Scroll;
            // 
            // CheckedFunc
            // 
            CheckedFunc.BackColor = System.Drawing.Color.SandyBrown;
            CheckedFunc.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            CheckedFunc.FormattingEnabled = true;
            CheckedFunc.ItemHeight = 17;
            CheckedFunc.Location = new System.Drawing.Point(1056, 325);
            CheckedFunc.Name = "CheckedFunc";
            CheckedFunc.Size = new System.Drawing.Size(218, 89);
            CheckedFunc.TabIndex = 16;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label1.Location = new System.Drawing.Point(690, 42);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(56, 17);
            label1.TabIndex = 17;
            label1.Text = "Degree";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label2.Location = new System.Drawing.Point(711, 86);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(16, 17);
            label2.TabIndex = 18;
            label2.Text = "X";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label3.Location = new System.Drawing.Point(711, 129);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(16, 17);
            label3.TabIndex = 19;
            label3.Text = "Y";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label4.Location = new System.Drawing.Point(711, 221);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(16, 17);
            label4.TabIndex = 20;
            label4.Text = "X";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label5.Location = new System.Drawing.Point(711, 263);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(16, 17);
            label5.TabIndex = 21;
            label5.Text = "Y";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label6.Location = new System.Drawing.Point(711, 355);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(16, 17);
            label6.TabIndex = 22;
            label6.Text = "X";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label7.Location = new System.Drawing.Point(711, 393);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(16, 17);
            label7.TabIndex = 23;
            label7.Text = "Y";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label8.Location = new System.Drawing.Point(1056, 222);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(16, 17);
            label8.TabIndex = 24;
            label8.Text = "X";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label9.Location = new System.Drawing.Point(1056, 264);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(16, 17);
            label9.TabIndex = 25;
            label9.Text = "Y";
            // 
            // DegLbl
            // 
            DegLbl.BackColor = System.Drawing.Color.Chocolate;
            DegLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            DegLbl.Location = new System.Drawing.Point(978, 42);
            DegLbl.Name = "DegLbl";
            DegLbl.Size = new System.Drawing.Size(65, 30);
            DegLbl.TabIndex = 3;
            DegLbl.Text = "\r\n";
            // 
            // RotX
            // 
            RotX.BackColor = System.Drawing.Color.Chocolate;
            RotX.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            RotX.Location = new System.Drawing.Point(978, 86);
            RotX.Name = "RotX";
            RotX.Size = new System.Drawing.Size(65, 30);
            RotX.TabIndex = 3;
            RotX.Text = "\r\n";
            // 
            // RotY
            // 
            RotY.BackColor = System.Drawing.Color.Chocolate;
            RotY.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            RotY.Location = new System.Drawing.Point(978, 129);
            RotY.Name = "RotY";
            RotY.Size = new System.Drawing.Size(65, 30);
            RotY.TabIndex = 27;
            RotY.Text = "\r\n";
            // 
            // TransX
            // 
            TransX.BackColor = System.Drawing.Color.Chocolate;
            TransX.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            TransX.Location = new System.Drawing.Point(978, 221);
            TransX.Name = "TransX";
            TransX.Size = new System.Drawing.Size(65, 30);
            TransX.TabIndex = 28;
            TransX.Text = "\r\n";
            // 
            // TransY
            // 
            TransY.BackColor = System.Drawing.Color.Chocolate;
            TransY.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            TransY.Location = new System.Drawing.Point(978, 263);
            TransY.Name = "TransY";
            TransY.Size = new System.Drawing.Size(65, 30);
            TransY.TabIndex = 29;
            TransY.Text = "\r\n";
            // 
            // ScaleX
            // 
            ScaleX.BackColor = System.Drawing.Color.Chocolate;
            ScaleX.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            ScaleX.Location = new System.Drawing.Point(978, 355);
            ScaleX.Name = "ScaleX";
            ScaleX.Size = new System.Drawing.Size(65, 30);
            ScaleX.TabIndex = 30;
            ScaleX.Text = "\r\n";
            // 
            // ScaleY
            // 
            ScaleY.BackColor = System.Drawing.Color.Chocolate;
            ScaleY.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            ScaleY.Location = new System.Drawing.Point(978, 393);
            ScaleY.Name = "ScaleY";
            ScaleY.Size = new System.Drawing.Size(65, 30);
            ScaleY.TabIndex = 31;
            ScaleY.Text = "\r\n";
            // 
            // ShearX
            // 
            ShearX.BackColor = System.Drawing.Color.Chocolate;
            ShearX.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            ShearX.Location = new System.Drawing.Point(1305, 221);
            ShearX.Name = "ShearX";
            ShearX.Size = new System.Drawing.Size(65, 30);
            ShearX.TabIndex = 32;
            ShearX.Text = "\r\n";
            // 
            // ShearY
            // 
            ShearY.BackColor = System.Drawing.Color.Chocolate;
            ShearY.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            ShearY.Location = new System.Drawing.Point(1305, 263);
            ShearY.Name = "ShearY";
            ShearY.Size = new System.Drawing.Size(65, 30);
            ShearY.TabIndex = 33;
            ShearY.Text = "\r\n";
            // 
            // Reset
            // 
            Reset.BackColor = System.Drawing.Color.SandyBrown;
            Reset.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            Reset.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            Reset.Location = new System.Drawing.Point(1290, 390);
            Reset.Name = "Reset";
            Reset.Size = new System.Drawing.Size(80, 41);
            Reset.TabIndex = 34;
            Reset.Text = "Reset";
            Reset.UseVisualStyleBackColor = false;
            Reset.Click += Reset_Click;
            // 
            // cbFlipY
            // 
            cbFlipY.Location = new System.Drawing.Point(397, 544);
            cbFlipY.Name = "cbFlipY";
            cbFlipY.Size = new System.Drawing.Size(112, 24);
            cbFlipY.TabIndex = 35;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (System.Drawing.Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new System.Drawing.Point(161, 506);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new System.Drawing.Size(125, 62);
            pictureBox2.TabIndex = 36;
            pictureBox2.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.Color.DeepSkyBlue;
            ClientSize = new System.Drawing.Size(1370, 711);
            Controls.Add(pictureBox1);
            Controls.Add(Reset);
            Controls.Add(ShearY);
            Controls.Add(ShearX);
            Controls.Add(ScaleY);
            Controls.Add(ScaleX);
            Controls.Add(TransY);
            Controls.Add(TransX);
            Controls.Add(RotY);
            Controls.Add(RotX);
            Controls.Add(DegLbl);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(CheckedFunc);
            Controls.Add(ShearYtrackBar);
            Controls.Add(ShearXtrackBar);
            Controls.Add(ScaleYtrackBar);
            Controls.Add(ScaleXtrackBar);
            Controls.Add(TransYtrackBar);
            Controls.Add(TransXtrackBar);
            Controls.Add(RotYtrackBar);
            Controls.Add(RotXtrackBar);
            Controls.Add(DegTrackBar);
            Controls.Add(Shear);
            Controls.Add(Scale);
            Controls.Add(Trans);
            Controls.Add(Rot);
            Controls.Add(cbFlipY);
            Controls.Add(pictureBox2);
            Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Form1";
            StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds;
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)DegTrackBar).EndInit();
            ((System.ComponentModel.ISupportInitialize)RotXtrackBar).EndInit();
            ((System.ComponentModel.ISupportInitialize)RotYtrackBar).EndInit();
            ((System.ComponentModel.ISupportInitialize)TransXtrackBar).EndInit();
            ((System.ComponentModel.ISupportInitialize)TransYtrackBar).EndInit();
            ((System.ComponentModel.ISupportInitialize)ScaleXtrackBar).EndInit();
            ((System.ComponentModel.ISupportInitialize)ScaleYtrackBar).EndInit();
            ((System.ComponentModel.ISupportInitialize)ShearXtrackBar).EndInit();
            ((System.ComponentModel.ISupportInitialize)ShearYtrackBar).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.CheckBox Rot;
        private System.Windows.Forms.CheckBox Trans;
        private System.Windows.Forms.CheckBox Scale;
        private System.Windows.Forms.CheckBox Shear;
        private System.Windows.Forms.TrackBar DegTrackBar;
        private System.Windows.Forms.TrackBar RotXtrackBar;
        private System.Windows.Forms.TrackBar RotYtrackBar;
        private System.Windows.Forms.TrackBar TransXtrackBar;
        private System.Windows.Forms.TrackBar TransYtrackBar;
        private System.Windows.Forms.TrackBar ScaleXtrackBar;
        private System.Windows.Forms.TrackBar ScaleYtrackBar;
        private System.Windows.Forms.TrackBar ShearXtrackBar;
        private System.Windows.Forms.TrackBar ShearYtrackBar;
        private System.Windows.Forms.ListBox CheckedFunc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label DegLbl;
        private System.Windows.Forms.Label RotX;
        private System.Windows.Forms.Label RotY;
        private System.Windows.Forms.Label TransX;
        private System.Windows.Forms.Label TransY;
        private System.Windows.Forms.Label ScaleX;
        private System.Windows.Forms.Label ScaleY;
        private System.Windows.Forms.Label ShearX;
        private System.Windows.Forms.Label ShearY;
        private System.Windows.Forms.Button Reset;
        private System.Windows.Forms.CheckBox cbFlipY;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

