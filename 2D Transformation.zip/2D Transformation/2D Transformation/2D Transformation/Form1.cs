﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

namespace _2D_Transformation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Reset_Click(object sender, EventArgs e)
        {
            Form1_Load(sender, null);
        }


        private void Rot_CheckedChanged(object sender, EventArgs e)
        {
            UpdateListBox((CheckBox)sender, "Rotate");
        }

        private void Trans_CheckedChanged(object sender, EventArgs e)
        {
            UpdateListBox((CheckBox)sender, "Translation");
        }

        private void Scale_CheckedChanged(object sender, EventArgs e)
        {
            UpdateListBox((CheckBox)sender, "Scale");
        }

        private void Xreflect_CheckedChanged(object sender, EventArgs e)
        {
            UpdateListBox((CheckBox)sender, "Xreflect");
        }

        private void Yreflect_CheckedChanged(object sender, EventArgs e)
        {
            UpdateListBox((CheckBox)sender, "Yreflect");
        }

        private void Shear_CheckedChanged(object sender, EventArgs e)
        {
            UpdateListBox((CheckBox)sender, "Shear");
        }

        private void DegTrackBar_Scroll(object sender, EventArgs e)
        {
            DegLbl.Text = DegTrackBar.Value.ToString();
            Rot.CheckState = CheckState.Checked;
            Image_Proccess(sender, null);
        }

        private void RotXtrackBar_Scroll(object sender, EventArgs e)
        {
            RotX.Text = RotXtrackBar.Value.ToString();
            Rot.CheckState = CheckState.Checked;
            Image_Proccess(sender, null);
        }

        private void RotYtrackBar_Scroll(object sender, EventArgs e)
        {
            RotY.Text = RotYtrackBar.Value.ToString();
            Rot.CheckState = CheckState.Checked;
            Image_Proccess(sender, null);
        }

        private void TransXtrackBar_Scroll(object sender, EventArgs e)
        {
            TransX.Text = TransXtrackBar.Value.ToString();
            Trans.CheckState = CheckState.Checked;
            Image_Proccess(sender, null);
        }

        private void TransYtrackBar_Scroll(object sender, EventArgs e)
        {
            TransY.Text = TransYtrackBar.Value.ToString();
            Trans.CheckState = CheckState.Checked;
            Image_Proccess(sender, null);
        }

        private void ScaleXtrackBar_Scroll(object sender, EventArgs e)
        {
            ScaleX.Text = ScaleXtrackBar.Value.ToString();
            Scale.CheckState = CheckState.Checked;
            Image_Proccess(sender, null);
        }

        private void ScaleYtrackBar_Scroll(object sender, EventArgs e)
        {
            ScaleY.Text = ScaleYtrackBar.Value.ToString();
            Scale.CheckState = CheckState.Checked;
            Image_Proccess(sender, null);
        }


        private void ShearXtrackBar_Scroll(object sender, EventArgs e)
        {
            ShearX.Text = ShearXtrackBar.Value.ToString();
            Shear.CheckState = CheckState.Checked;
            Image_Proccess(sender, null);
        }

        private void ShearYtrackBar_Scroll(object sender, EventArgs e)
        {
            ShearY.Text = ShearYtrackBar.Value.ToString();
            Shear.CheckState = CheckState.Checked;
            Image_Proccess(sender, null);
        }

        private void UpdateListBox(CheckBox sender, string v)
        {
            if (sender.CheckState == CheckState.Checked)
            {
                bool found = false;
                for (int i = 0; i < CheckedFunc.Items.Count; i++)
                    if (CheckedFunc.Items[i].ToString() == v)
                    {
                        found = true;
                        break;
                    }

                if (!found)
                {
                    CheckedFunc.Items.Add(v);
                    CheckedFunc.SelectedIndex = CheckedFunc.Items.Count - 1;
                }

            }
            else
            {
                for (int i = 0; i < CheckedFunc.Items.Count; i++)
                {
                    if (CheckedFunc.Items[i].ToString() == v)
                    {
                        reset_spacific_transition(CheckedFunc.Items[i].ToString());

                        CheckedFunc.Items.RemoveAt(i);

                        if (i > 0) CheckedFunc.SelectedIndex = i - 1;
                        if (i == 0)
                            if (CheckedFunc.Items.Count >= 1)
                                CheckedFunc.SelectedIndex = 0;

                        break;
                    }
                }
            }
        }

        private void reset_spacific_transition(string v)
        {
            if (v == "Translation")
            {
                TransXtrackBar.Value = 0;
                TransYtrackBar.Value = 0;

                TransX.Text = TransXtrackBar.Value.ToString();
                TransY.Text = TransYtrackBar.Value.ToString();
            }
            else if (v == "Scale")
            {
                ScaleXtrackBar.Value = 10;
                ScaleYtrackBar.Value = 10;

                ScaleX.Text = String.Format("{0:0.0}", (ScaleXtrackBar.Value / 10.0));
                ScaleY.Text = String.Format("{0:0.0}", (ScaleYtrackBar.Value / 10.0));
            }
            else if (v == "Shear")
            {
                ShearXtrackBar.Value = 0;
                ShearYtrackBar.Value = 0;

                ShearX.Text = ShearXtrackBar.Value.ToString();
                ShearY.Text = ShearYtrackBar.Value.ToString();
            }
            else if (v == "Rotate")
            {
                DegTrackBar.Value = 0;
                RotXtrackBar.Value = 0;
                RotYtrackBar.Value = 0;

                DegLbl.Text = DegTrackBar.Value.ToString();
                RotX.Text = RotXtrackBar.Value.ToString();
                RotY.Text = RotYtrackBar.Value.ToString();

            }
            Image_Proccess(this, null);
        }

        private void Form1_Load(object sender, object p)
        {
            DegTrackBar.Value = 0;
            RotXtrackBar.Value = 0;
            RotYtrackBar.Value = 0;

            DegLbl.Text = DegTrackBar.Value.ToString();
            RotX.Text = RotXtrackBar.Value.ToString();
            RotY.Text = RotYtrackBar.Value.ToString();

            TransXtrackBar.Value = 0;
            TransYtrackBar.Value = 0;

            TransX.Text = TransXtrackBar.Value.ToString();
            TransY.Text = TransYtrackBar.Value.ToString();

            ScaleXtrackBar.Value = 10;
            ScaleYtrackBar.Value = 10;

            ScaleX.Text = String.Format("{0:0.0}", (ScaleXtrackBar.Value / 10.0));
            ScaleY.Text = String.Format("{0:0.0}", (ScaleYtrackBar.Value / 10.0));

            ShearXtrackBar.Value = 0;
            ShearYtrackBar.Value = 0;

            ShearX.Text = ShearXtrackBar.Value.ToString();
            ShearY.Text = ShearYtrackBar.Value.ToString();

            cbFlipY.CheckState = CheckState.Checked;
            Rot.CheckState = CheckState.Unchecked;
            Trans.CheckState = CheckState.Unchecked;
            Scale.CheckState = CheckState.Unchecked;
            Shear.CheckState = CheckState.Unchecked;
            Xreflect.CheckState = CheckState.Unchecked;
            Yreflect.CheckState = CheckState.Unchecked;

            Image_Proccess(this, null);
        }

        private void Image_Proccess(object sender, object p)
        {
            Image img = new Bitmap(400, 400);

            pictureBox1.Image = img;
            Graphics g = Graphics.FromImage(pictureBox1.Image);


            Matrix Mat = new Matrix();
            Mat.Translate(0, 0, MatrixOrder.Append);

            g.Transform = Mat;

            for (int i = 0; i < CheckedFunc.Items.Count; i++)
            {

                if (CheckedFunc.Items[i].ToString() == "Xreflect")
                {
                    Matrix mreflex = new Matrix(1, 0, 0, -1, 0, 0);
                    Mat.Multiply(mreflex, MatrixOrder.Append);
                }

                if (CheckedFunc.Items[i].ToString() == "Yreflect")
                {
                    Matrix mreflex = new Matrix(-1, 0, 0, 1, 0, 0);
                    Mat.Multiply(mreflex, MatrixOrder.Append);
                }

                if (CheckedFunc.Items[i].ToString() == "Rotate")
                    Mat.RotateAt(
                        (cbFlipY.CheckState == CheckState.Checked ? -1 : 1) * int.Parse(DegLbl.Text),
                        new Point(int.Parse(RotX.Text), int.Parse(RotY.Text)),
                        MatrixOrder.Append);


                if (CheckedFunc.Items[i].ToString() == "Translation")
                    Mat.Translate(int.Parse(TransX.Text), int.Parse(TransY.Text), MatrixOrder.Append);

                if (CheckedFunc.Items[i].ToString() == "Scale")
                    Mat.Scale(float.Parse(ScaleX.Text), float.Parse(ScaleY.Text), MatrixOrder.Append);

                if (CheckedFunc.Items[i].ToString() == "Shear")
                {
                    Mat.Shear(float.Parse(ShearX.Text), float.Parse(ShearY.Text), MatrixOrder.Append);
                }

            }
            GraphicsPath gp = new GraphicsPath();
            Image imgpic = (Image)pictureBox2.Image.Clone();

            PointF[] psrc;

            psrc = new PointF[] { new Point(0, imgpic.Height), new Point(imgpic.Width, imgpic.Height), new Point(0, 0) };

            gp.AddPolygon(psrc);

            gp.Transform(Mat);
            PointF[] pts = gp.PathPoints;

            g.DrawImage(imgpic, pts);


            pictureBox1.Refresh();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
